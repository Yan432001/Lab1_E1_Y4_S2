<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attedencdent</title>
</head>
<style>
    .form-container {
        width: 355px;
        margin: 0 auto;
        border: 1px solid black;
        padding: 20px;
        background-color: lightgray;
    }

    h1 {
        text-align: center;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        border: 3px solid purple;
    }

    .table table,
    .table th,
    .table td {
        padding: 20px;

    }

    .ex input {
        width: 337px;
        padding: 5px;
    }

    input,
    select {
        padding: 3px;

    }

    .tbody {
        text-align: center;
    }
</style>

<body>

    <?php


    if (!isset($_GET["fname"])) {

        ?>
        <div class="form-container">
            <h1>Attedencdent Form</h1>

            <form method="get">
                <table>
                    <tr>
                        <td class="ex"><label for="">First Name</label><br><input type="text" name="fname" required></td>
                    </tr>
                    <tr>
                        <td class="ex"><label for="">Last Name</label><br><input type="text" name="lname" id="" required>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="">Gender</label><br>
                            <input type="radio" name="gender" value="male" id="" required>Male
                            <input type="radio" name="gender" value="female" id="">Female
                            <input type="radio" name="gender" value="other" id="">Other
                        </td>
                    </tr>
                    <tr>
                        <td class="ex"><label for="">E-mail</label><br>
                            <input type="email" name="email" required>
                        </td>
                    </tr>
                    <tr>
                        <td class="ex"><label for="">Date</label><br>
                            <input type="date" name="date" id="" required>
                        </td>
                    </tr>

                    <tr>
                        <td class="ex">
                            <label for="">Department</label><br>
                            <select name="department" id="department" style="width: 344px;" required>

                                <optgroup label="Faculty of Science">
                                    <option value="Mathematics">Mathematics</option>
                                    <option value="General Biology">General Biology</option>
                                    <option value="General Biology">General Biology</option>
                                    <option value="Chemistry">Chemistry</option>
                                    <option value="Biochemistry">Biochemistry</option>
                                    <option value="Physics">Physics</option>
                                    <option value="Computer Science and Engineering">Computer Science and Engineering
                                    </option>
                                    <option value="Environmental Science">Environmental Science</option>
                                </optgroup>

                                <optgroup label="Faculty of Social Science and Humanities">
                                    <option value="Khmer Literature">Khmer Literature</option>
                                    <option value="Tourism">Tourism</option>
                                    <option value=" Geography and Land Management"> Geography and Land Management</option>
                                    <option value="Media and Communication">Media and Communication</option>
                                    <option value="Sociology">Sociology</option>
                                    <option value="Social Work">Social Work</option>
                                    <option value="International Business Management (IBM)">International Business
                                        Management (IBM)</option>
                                    <option value="Linguistics">Linguistics</option>
                                </optgroup>


                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="ex">
                            <label for="">Class</label><br>
                            <select name="class" id="class" style="width: 344px;" required>

                                <optgroup label="Morning">
                                    <option value="M1">M1</option>
                                    <option value="M2">M2</option>
                                    <option value="M3">M3</option>
                                    <option value="M4">M4</option>
                                    <option value="M5">M5</option>
                                    <option value="M6">M6</option>
                                    <option value="M7">M7</option>
                                    <option value="M8">M8</option>
                                </optgroup>
                                <optgroup label="Afternoon">
                                    <option value="A1">A1</option>
                                    <option value="A2">A2</option>
                                    <option value="A3">A3</option>
                                    <option value="A4">A4</option>
                                    <option value="A5">A5</option>
                                    <option value="A6">A6</option>
                                    <option value="A7">A7</option>
                                    <option value="A8">A8</option>
                                </optgroup>
                                <optgroup label="Evening">
                                    <option value="E1">E1</option>
                                    <option value="E2">E2</option>
                                    <option value="E3">E3</option>
                                    <option value="E4">E4</option>
                                    <option value="E5">E5</option>
                                    <option value="E6">E6</option>
                                    <option value="E7">E7</option>
                                    <option value="E8">E8</option>
                                </optgroup>

                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="">Study Time</label><br>
                            <input type="checkbox" name="time[]" value="First" id="">First Time 
                            <input type="checkbox" name="time[]" value="Second" id="">Second Time 
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 337px" class="ex">
                            <label for="">Reason</label><br>
                            <textarea name="reason" id="" cols="43" rows="3" required></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td dir="rtl">
                            <input type="submit" value="SUBMIT"
                                style="background-color:fuchsia; color: white; padding: 7px;">
                        </td>
                    </tr>
                </table>
            </form>
        </div>


        <?php

    } else { ?>


        <div class="table">
            <h1>Attedencdent List</h1>
            <table>

                <thead>
                    <tr>
                        <th style="width: 9%">First Name</th>
                        <th style="width: 9%">Last Name</th>
                        <th style="width: 80px">Gender</th>
                        <th>Email</th>
                        <th style="width:80px">Date</th>
                        <th>Department</th>
                        <th style="width: 40px">Class</th>
                        <th style="width: 80px">Time</th>
                        <th>Reason</th>
                    </tr>
                </thead>
                <tbody class="tbody">
                    <tr>
                        <td style="width: 9%">
                            <?= $_GET["fname"] ?>
                        </td>
                        <td style="width: 9%">
                            <?= $_GET["lname"] ?>
                        </td>
                        <td style="width: 80px">
                            <?= $_GET["gender"] ?>
                        </td>
                        <td>
                            <?= $_GET["email"] ?>
                        </td>
                        <td style="width: 50px">
                            <?= $_GET["date"] ?>
                        </td>
                        <td>
                            <?= $_GET["department"] ?>
                        </td>
                        <td style="width: 40px">
                            <?= $_GET["class"] ?>
                        </td>
                        <td style="width: 50px">
                            <?php
                            if (!empty($_GET['time'])) {
                                foreach ($_GET['time'] as $select) {
                                    echo $select . "<br>";
                                }
                            }
                            ?>
                        </td>
                        <td>
                            <?= $_GET["reason"] ?>
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>
    <?php }
    ?>

</body>

</html>

<?php
?>